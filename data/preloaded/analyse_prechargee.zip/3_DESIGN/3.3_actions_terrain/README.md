# Actions à vérifier sur le terrain
Les pistes de `3.2_pistes_amelioration/pistes.csv` sont des points de contrôle. Une cause potentielle reste une hypothèse.
