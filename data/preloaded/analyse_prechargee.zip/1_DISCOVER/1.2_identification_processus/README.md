# Identification du processus
Processus : assemblage du modèle Dreamliner, en 56 opérations séquentielles, une par poste.
Le relevé forme une séquence observée. Activité : intitulé MES (`Nom`) ; la clé est le numéro de poste.
