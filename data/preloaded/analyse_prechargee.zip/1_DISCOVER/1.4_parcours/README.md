# Visualisation des parcours
Le parcours observé est `flow_edges.csv` au grain opération et `zone_edges.csv` au grain zone.
