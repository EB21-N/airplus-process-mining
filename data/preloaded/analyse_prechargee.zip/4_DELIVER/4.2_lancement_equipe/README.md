# Lancement par l'équipe
Lancer le dashboard avec le lanceur de son système, ouvrir l'analyse préchargée ou importer les trois Excel.
