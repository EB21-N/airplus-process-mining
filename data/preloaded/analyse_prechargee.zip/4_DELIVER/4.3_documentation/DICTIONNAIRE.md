# Dictionnaire des tables

CSV UTF-8 avec BOM, séparateur `;`. Provenance : `MES!L32` = fichier MES, ligne Excel 32 ; `PLM!Sheet1!L6` ; `ERP!RESSOURCES!L2`.

| Fichier | Granularité | Clé |
|---|---|---|
| `1_DISCOVER/1.1_extraction_journal/operations.csv` | Une ligne = une opération MES (une ligne Excel, un poste). | op_id |
| `1_DISCOVER/1.1_extraction_journal/event_log.csv` | Une ligne = un événement (début ou fin) d'une opération. | event_id |
| `1_DISCOVER/1.1_extraction_journal/op_refs.csv` | Une ligne = une référence distincte dans une opération, avec son nombre d'occurrences. Ne pas sommer les durées ici. | op_id, ref |
| `1_DISCOVER/1.1_extraction_journal/parts.csv` | Une ligne = une référence PLM. | ref |
| `1_DISCOVER/1.1_extraction_journal/persons_pseudonymises.csv` | Une ligne = un profil ERP pseudonymisé. | person_id |
| `1_DISCOVER/1.1_extraction_journal/person_skills.csv` | Une ligne = une compétence déclarée d'un profil. | person_id, competence |
| `1_DISCOVER/1.1_extraction_journal/person_rotations.csv` | Une ligne = une rotation déclarée d'un profil. Semaines non datées. | person_id, semaine |
| `1_DISCOVER/1.1_extraction_journal/mesh_links.csv` | Une ligne = une occurrence maillée du modèle 3D. | occurrence_id |
| `1_DISCOVER/1.3_cartographie_flux/flow_edges.csv` | Une ligne = une transition entre deux opérations consécutives. | de, vers |
| `1_DISCOVER/1.3_cartographie_flux/zones.csv` | Une ligne = une zone d'opérations (regroupement par règle sur l'intitulé). | zone |
| `1_DISCOVER/1.3_cartographie_flux/zone_edges.csv` | Une ligne = un passage entre deux zones. | de, vers |
| `2_DEFINE/2.1_perimetre/jointures.csv` | Une ligne = une jointure avec sa couverture. | jointure |
| `2_DEFINE/2.2_caracterisation/postes.csv` | Une ligne = un poste de référence. | poste |
| `2_DEFINE/2.3_indicateurs/kpis.csv` | Une ligne = un indicateur calculé. | kpi_id |
| `2_DEFINE/2.3_indicateurs/fournisseurs.csv` | Une ligne = un fournisseur (agrégat de références PLM). | fournisseur |
| `2_DEFINE/2.4_ecarts/anomalies.csv` | Une ligne = une anomalie ou un contrôle. | anomalie_id |
| `2_DEFINE/2.4_ecarts/reconciliation_references.csv` | Une ligne = une référence, comparée entre PLM, notice, MES et modèle 3D. | ref |
| `2_DEFINE/2.4_ecarts/goulots_candidats.csv` | Une ligne = une opération dont le dépassement est à investiguer. | op_id |
| `2_DEFINE/2.5_supply_chain/abc_references.csv` | Une ligne = une référence avec sa classe ABC sur la valeur de nomenclature. | ref |
| `2_DEFINE/2.5_supply_chain/flux_fournisseur_zone.csv` | Une ligne = un fournisseur et une zone, avec les pièces citées au MES. | fournisseur, zone |
| `2_DEFINE/2.5_supply_chain/retroplanning_commandes.csv` | Une ligne = une référence citée au MES : premier usage moins délai PLM. | ref |
| `2_DEFINE/2.5_supply_chain/criticite_delai.csv` | Une ligne = une criticité et une tranche de délai. | criticite, delai |
| `2_DEFINE/2.5_supply_chain/postes_approvisionnement.csv` | Une ligne = un poste avec les délais et fournisseurs de ses pièces. | poste |
| `2_DEFINE/2.5_supply_chain/ecarts_nomenclature_mes.csv` | Une ligne = une référence dont les occurrences MES diffèrent de la nomenclature. | ref |
| `3_DESIGN/3.1_processus_cible/processus_cible.csv` | Une ligne = une opération de la séquence ; la durée cible est le Temps Prévu source. | op_id |
| `3_DESIGN/3.2_pistes_amelioration/pistes.csv` | Une ligne = une piste dérivée par règle, sans gain chiffré. | piste_id |
| `general/table_generale.csv` | Une ligne = une référence distincte dans une opération (ou l'opération seule si la référence manque). Les colonnes op_* sont au grain opération : les sommer uniquement sur ligne_operation_1 = 1. Les profils sont listés dans une seule cellule pour ne pas multiplier les lignes. | op_id, ref |

## Mesures de durée
- `prevu_s` : colonne Temps Prévu.
- `reel_s` : colonne Temps Réel, le réel déclaré.
- `horo_s` : Heure Fin − Heure Début.
- `ecart_horo_reel_s` : écart conservé entre horodatages et déclaré.

## Identités
`person_id` est dérivé par HMAC d'un secret calculé sur le fichier ERP. Le secret n'est pas publié. Ni nom complet ni matricule dans cette archive. L'âge n'est pas repris.
