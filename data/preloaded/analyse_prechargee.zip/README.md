# Analyse Air+
Moteur 1.0.0. Empreinte du contenu `2f1a3a60cfba50106567c61af821197fe9645b2d7fc426c4339cd35b11120b8e`.
Dossiers : 1_DISCOVER, 2_DEFINE, 3_DESIGN, 4_DELIVER, general, dashboard.
À recharger dans le dashboard Air+ : menu Données > Ouvrir un ZIP d'analyse.
